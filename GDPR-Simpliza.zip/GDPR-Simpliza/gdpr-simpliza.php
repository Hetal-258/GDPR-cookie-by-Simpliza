<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://http://localhost/demo/
 * @since             1.0.0
 * @package           Gdpr_Simpliza
 *
 * @wordpress-plugin
 * Plugin Name:       GDPR cookie by Simpliza
 * Plugin URI:        https://GDPR cookie by Simpliza
 * Description:        A CookieDisplay plugin to demonstrate wordpress functionality
 * Version:           1.0.0
 * Author:            Simpliza
 * Author URI:        https://http://localhost/demo/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       gdpr-simpliza
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'GDPR_SIMPLIZA_VERSION', '1.0.0' );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-gdpr-simpliza-activator.php
 */
function activate_gdpr_simpliza() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-gdpr-simpliza-activator.php';
	Gdpr_Simpliza_Activator::activate();
}
/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-gdpr-simpliza-deactivator.php
 */
function deactivate_gdpr_simpliza() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-gdpr-simpliza-deactivator.php';
	Gdpr_Simpliza_Deactivator::deactivate();
}
register_activation_hook( __FILE__, 'gdpr_cookie_add_plugin_page' );
register_deactivation_hook( __FILE__, 'deactivate_gdpr_simpliza' );
/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-gdpr-simpliza.php';
/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_gdpr_simpliza() {
	$plugin = new Gdpr_Simpliza();
	$plugin->run();
}
run_gdpr_simpliza();
add_action( 'admin_menu',  'gdpr_cookie_add_plugin_page'  );
add_action( 'admin_init',  'gdpr_cookie_page_init'  );

 function gdpr_cookie_add_plugin_page() {

  $textarea_value = get_option('gdpr_codeeditor');

  if($textarea_value == '') {
      $default_json = '   apps: [
          {
            name: "functional-cookies",
            title: "Functional cookies",
            purposes: ["browsing"],
            required: true
          },

          {
            name: "analytics",
            title: "Tracking cookies",
            purposes: ["analytics"],
            cookies: ["inline-tracker"],
            default: false,
                cookies: [
                        "_ga",
                        "_gat",
                        "_gid",
                        "__utma",
                        "__utmb",
                        "__utmc",
                        "__utmt",
                        "__utmz",
                    "_gat_gtag_" + GTM_UA,
                    "_gat_" + GTM_UA
                ],
          },
          {
            name: "targeting-advertising",
            title: "Targeting and advertising cookies",
            purposes: ["ads"],
            default: false
          },

        ],
        categories: [
          {
            name: "example",
            title: "Required cookies",
            apps: ["functional-cookies"]
          },
          {
            name: "third-party",
            title: "Tracking cookies",
            apps: ["analytics","targeting-advertising"]
          }
        ]  ';

        update_option('gdpr_codeeditor', $default_json);
  }

  add_menu_page(
      'GDPR Cookie', // page_title
      'GDPR Cookie', // menu_title
      'manage_options', // capability
      'gdpr-cookie', // menu_slug
      'gdpr_cookie_html_page', // function
      'dashicons-admin-settings', // icon_url
      80 // position
    );
}
function gdpr_cookie_html_page() {
  // check user capabilities
  if ( ! current_user_can( 'manage_options' ) ) {
    return;
  }
  $default_tab = 'general';
  $tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;
   ?>
    <div class="wrap">
    <!-- Print the page title -->
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    <!-- Here are our tabs -->
    <nav class="nav-tab-wrapper">          
          <a href="?page=gdpr-cookie&tab=general" class="nav-tab <?php if($tab == 'general') { echo 'nav-tab-active'; } else { echo ''; } ?>">General</a>
          <a href="?page=gdpr-cookie&tab=cookie" class="nav-tab <?php if($tab == 'cookie') { echo 'nav-tab-active'; } else { echo ''; } ?>">Cookie</a>
    </nav>

    <div class="tab-content">
    <?php
     switch($tab) :
      case 'general':
        settings_errors();
        echo'  <form method="post" action="options.php">';
         settings_fields( 'gdpr_general_option_group' );
          do_settings_sections( 'gdpr-general-admin' );
          submit_button();
       
      echo '</form>';
       //Put your HTML here
        break;
     case 'cookie':
         //mytheme_general_options();
        settings_errors();
          echo'  <form method="post" action="options.php">';          
          settings_fields( 'gdpr_cookie_option_group' );
          do_settings_sections( 'gdpr-cookie-admin' );
          submit_button();
       
      echo '</form>';
        break;
    default:
            break;
    endswitch; ?>
    </div>
  </div>
  <?php
}
function gdpr_cookie_page_init() {    
  /* general option group */
    register_setting("gdpr_general_option_group", "gtm_tag");
    register_setting("gdpr_general_option_group", "terms_condition_page");
    register_setting("gdpr_general_option_group", "gdpr_lang");
    register_setting("gdpr_general_option_group", "savebtn_color");
    register_setting('gdpr_general_option_group','gdpr_cookie_option_name'); 
    register_setting("gdpr_cookie_option_group", "gdpr_codeeditor");// sanitize_callback 

  add_settings_section("gdpr_general_option_group", null, null, "gdpr-general-admin");
  add_settings_section("gdpr_cookie_option_group", null, null, "gdpr-cookie-admin");

  add_settings_field("gtm_tag", "GTM Tag", "gtm_callback", "gdpr-general-admin", "gdpr_general_option_group");
	add_settings_field("gdpr_lang", "Language", "lang_callback", "gdpr-general-admin", "gdpr_general_option_group");
   add_settings_field("terms_condition_page", "Privacy Policy Page", "terms_condition_page_callback", "gdpr-general-admin", "gdpr_general_option_group");
  add_settings_field("savebtn_color", "Color Picker Of Save Button", "colorpicker_savebtn", "gdpr-general-admin", "gdpr_general_option_group");
  add_settings_field("gdpr_codeeditor", "Code Editor", "codeeditor_callback", "gdpr-cookie-admin", "gdpr_cookie_option_group");  
   /* general option group end */

 
  }
  function gtm_callback(){?>
    <input type="text" name="gtm_tag" id="gtm_tag" value="<?php echo get_option('gtm_tag'); ?>" />
   <?php }
  function terms_condition_page_callback(){
    $terms_condition_page_val = get_option('terms_condition_page');
  ?> 
  <select name="terms_condition_page">    
      <?php 
        $my_wp_query = new WP_Query();
        $all_wp_pages = $my_wp_query->query( array(
            'post_type' => 'page',
            'posts_per_page' => -1
        )); foreach ($all_wp_pages as $value){
            $post = get_page($value);
            $title = $post->post_title;
            $id = $post->ID;
            if($terms_condition_page_val == $id ) {
               $selected = ' selected';
            }else{
              $selected = '';
            }  
     ?>
       <option value="<?php echo $id;?>"<?php echo $selected; ?>><?php echo $title; ?></option>
       <?php } ?>
    </select>
 <?php
  }
  function codeeditor_callback(){
    $url = plugin_dir_url( __FILE__ );
    $textarea_value = get_option('gdpr_codeeditor');
     ?>
    <link rel=stylesheet href="<?php echo $url; ?>editor/lib/codemirror.css">
    <script src="<?php echo $url; ?>editor/lib/codemirror.js"></script>
    <script src="<?php echo $url; ?>editor/mode/xml/xml.js"></script>
    <script src="<?php echo $url; ?>editor/mode/javascript/javascript.js"></script>
    <script src="<?php echo $url; ?>editor/mode/css/css.js"></script>
    <script src="<?php echo $url; ?>editor/mode/htmlmixed/htmlmixed.js"></script>
    <style>
      .CodeMirror { height: auto; border: 1px solid #ddd; }
      .CodeMirror pre { padding-left: 7px; line-height: 1.25; }

    </style>
<section id=demo>
  <form style="position: relative; margin-top: .5em;">
  <textarea id="code_editor" name="gdpr_codeeditor" rows="50" cols="50">
  <?php echo isset( $textarea_value ) ? esc_textarea( $textarea_value ) : '' ?>
  </textarea>
  </form>
  <script>
      var demoeditor = CodeMirror.fromTextArea(document.getElementById("code_editor"),{
      lineNumbers: true }).value;
      var parseJSON = JSON.parse(demoeditor);
      var JSONInPrettyFormat = JSON.stringify(parseJSON, undefined, 4);
      CodeMirror.fromTextArea(document.getElementById('code_editor')).value = JSONInPrettyFormat;
      demoeditor.setSize("100%", "250px");
  </script>
</section>
 <?php }
  function lang_callback(){
    ?> <?php  $gdpr_lang = get_option('gdpr_lang');
        ?>  
        <select name="gdpr_lang">    
        <option value="en" <?php echo $gdpr_lang == 'en' ? 'selected' : ''; ?>>English</option>
        <option value="de" <?php echo $gdpr_lang == 'de' ? 'selected' : ''; ?>>German</option>
        <option value="fr" <?php echo $gdpr_lang == 'fr' ? 'selected' : ''; ?>>French</option>
        <option value="hu" <?php echo $gdpr_lang == 'hu' ? 'selected' : ''; ?>>Hungarian </option>
        <option value="it" <?php echo $gdpr_lang == 'it' ? 'selected' : ''; ?>>Italian</option>
        <option value="nb" <?php echo $gdpr_lang == 'nb' ? 'selected' : ''; ?>>Norwegian Bokmål</option>
        <option value="nl" <?php echo $gdpr_lang == 'nl' ? 'selected' : ''; ?>>Dutch</option>
        <option value="ro" <?php echo $gdpr_lang == 'ro' ? 'selected' : ''; ?>>Romanian</option>
        </select>
   <?php
    }
    function colorpicker_savebtn(){
      $save_color = get_option('savebtn_color');
      ?>
     <input type="color" class="savecolor_picker" name="savebtn_color" id='colorpicker' value="<?php echo $save_color;?>" />
     <input type="text" value="<?php echo $save_color;?>" id="hexcolor"></input>
   <?php }
  //menu items
add_action('wp_head','GDPRCookiedata_display');
function GDPRCookiedata_display(){
 $terms_condition_page_val = get_option('terms_condition_page');
 $gtm_tag = get_option('gtm_tag');
 $codeeditor = get_option('gdpr_codeeditor');
if($gtm_tag != '') {
?>
<!-- Google Tag Manager by gdpr cookie plugin //analytics-->
<script type="opt-in" data-type="application/javascript" data-name="targeting-advertising">
    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','<?php echo $gtm_tag; ?>');</script>
<!-- End Google Tag Manager -->
<?php } ?>
<script type="text/javascript">
var GTM_UA = '<?php echo $gtm_tag; ?>';
var lang = '<?php echo get_option('gdpr_lang');?>';
    var href = window.location.href;
    window.orejimeConfig = {
    privacyPolicy: "<?php echo get_permalink( $terms_condition_page_val ); ?>",
    lang: lang, // en
    translations: {},
    debug: false,
     translations: {
         en: {
            consentModal: {
              description: "This panel allows you to express your consent preferences to the tracking technologies we adopt and offer the features described below.",
            },
            "functional-cookies": {
            title: "Functional cookies",
            description: "Analytical cookies and technologies help us understand how people interact with our website. This helps us improve our website, apps, and communications, and helps us show you interesting and relevant content.",
            },
            "analytics": {
            title: "Cookies for behavior analysis ",
            description: "Analytical cookies and technologies help us understand how people interact with our website. This helps us improve our website, apps, and communications, and helps us show you interesting and relevant content.",
            },
            "targeting-advertising": {
            title: "Targeting and advertising cookies",
            description: "We and other trusted partners collect information about user journeys through cookies and other tracking technologies to deliver relevant sponsored content about our products.",
            },
            "external-tracker": {
              description: "Example of an external tracking script that sets a dummy cookie",
            },
            "always-on": {
              description: "This example app will not set any cookie",
            },
            "disabled-by-default": {
              description: "This example app will not set any cookie",
            },
            purposes: {
              analytics: "Analytics",
              security: "Security",
              ads: "Targeting",
              browsing: "Browsing"
            },
            categories: {
              example: {
                description: 'These cookies are essential to provide you with services available through our website and to enable you to use certain features of the  website.'
              },
              "third-party": {
                description: 'These cookies are used to collect information to analyze the traffic to our website and how visitors are using the website.'
              }
            }
          },
         it:{
            consentModal: {
              description: "Questo pannello consente di esprimere le proprie preferenze di consenso alle tecnologie di tracciamento che adottiamo ed offrire le funzionalità sotto descritte.",
            },
            "functional-cookies": {
            title: "Cookie funzionali",
            description: "Cookie di base necessari per la navigazione.",
            },
            "analytics": {
            title: "Cookies di analisi del comportamento",
            description: "Cookie e tecnologie di analisi ci aiutano a capire come le persone interagiscono con il sito Web. Questo ci aiuta a migliorare il servizio fornito ed a proporre contenuti pertinenti.",
            },
            "targeting-advertising": {
            title: "Cookies di targeting e pubblicità",
            description: "Noi e partner di fiducia raccogliamo informazioni sui comportamenti degli utenti attraverso cookie e altre tecnologie di tracciamento per fornire contenuti sponsorizzati pertinenti.",
            },
            "external-tracker": {
              description: "Esempio di uno script di tracciamento esterno che imposta un cookie fittizio",
            },
            purposes: {
            analytics: "analisi",
            security: "sicurezza",
            ads: "targeting",
            browsing: "navigazione",
            },
            categories: {
              example: {
                title: 'Cookies necessari',
                description: 'Questi cookie sono essenziali per fornirti i servizi disponibili sul sito Web e per consentire di utilizzare alcune specifiche funzionalità.'
              },
              "third-party": {
                title: 'Cookies di analisi',
                description: 'Questi cookie vengono utilizzati per raccogliere informazioni per analizzare il traffico verso il sito Web e il modo in cui i visitatori utilizzano il sito Web.'
              }
            },
          accept: "Accetta",
          acceptAll: "Accetta tutto",
          declineAll: "Declina tutto",
          enabled: "abilitato",
          disabled: "disabilitato",
         },
         
         
        de:{
          "analytics": {
              description: "Beispiel für ein Inline-Tracking-Skript, das ein Dummy-Cookie setzt",
            },
            "external-tracker": {
              description: "Beispiel für ein externes Tracking-Skript, das ein Dummy-Cookie setzt",
            },
            "always-on": {
              description: "Diese Beispielanwendung setzt keine Cookies",
            },
            "disabled-by-default": {
              description: "Diese Beispielanwendung setzt keine Cookies",
            },
           accept: "Akzeptieren",
           acceptAll: "Alle Anwendungen akzeptieren,",
           declineAll: "Alle Anwendungen ablehnen",
           enabled: "Aktiviert",
           disabled: "deaktiviert",
            categories: {
              example: {
                description: 'Die Anwendungen können in Kategorien eingeteilt werden, damit die Nutzer ihre Verwendung besser verstehen.'
              },
              "third-party": {
                description: 'Dies sind gefälschte Anwendungen von Drittanbietern.'
              }
            },
            purposes: {
                analytics: "Analytik",
                security: "Sicherheit",
                ads: "Anzeigen"
            },
            poweredBy: "Realisiert mit Orejime",
         },
         fr:{
          "analytics": {
              description: "Exemple d'un script de suivi en ligne qui définit un cookie factice",
            },
            "external-tracker": {
              description: "Exemple d'un script de suivi externe qui définit un cookie factice",
            },
            "always-on": {
              description: "Cet exemple d'application n'installera aucun cookie",
            },
            "disabled-by-default": {
              description: "Cet exemple d'application n'installera aucun cookie",
            },
          categories: {
              example: {
                description: 'Die Anwendungen können in Kategorien eingeteilt werden, damit die Nutzer ihre Verwendung besser verstehen.'
              },
              "third-party": {
                description: 'Dies sind gefälschte Anwendungen von Drittanbietern.'
              }
            },
            purposes: {
                analytics: "Analytique",
                security: "sécurité",
                ads: "annonces"
            },
         },
         hu:{
           "analytics": {
              description: "Példa egy online nyomkövető szkriptre, amely beállít egy dummy sütit",
            },
            "external-tracker": {
              description: "Példa egy külső nyomkövető szkriptre, amely egy dummy sütit állít be",
            },
            "always-on": {
              description: "Ez a példaalkalmazás nem állít be semmilyen sütit",
            },
            "disabled-by-default": {
              description: "Ez a példaalkalmazás nem állít be semmilyen sütit",
            },
            purposes: {
              analytics: "analitika",
              security: "biztonság",
              ads: "hirdetések"
            },
            categories: {
              example: {
                description: 'Az alkalmazások kategóriákba sorolhatók, hogy a felhasználók jobban megértsék használatukat.'
              },
              "third-party": {
                description: 'Ezek hamis harmadik féltől származó alkalmazások.'
              }
            },
          accept: "elfogadja",
          acceptAll: "fogadj el mindent,",
          declineAll: "csökkenés Minden",
          enabled: "engedélyezve",
          disabled: "fogyatékkal",
          poweredBy: "Az Orejime által üzemeltetett",  
         },
         nb:{
          "analytics": {
              description: "Eksempel på et innebygd sporingsskript som angir en dummy-informasjonskapsel",
            },
            "external-tracker": {
              description: "Eksempel på et eksternt sporingsskript som angir en dummy-informasjonskapsel",
            },
            "always-on": {
              description: "Dette eksempelet app vil ikke sette noen cookie",
            },
            "disabled-by-default": {
              description: "Dette eksempelet app vil ikke sette noen cookie",
            },
            purposes: {
              analytics: "Analytics",
              security: "sikkerhet",
              ads: "Annonser"
            },
            categories: {
              example: {
                description: 'Programmer kan grupperes i kategorier for å hjelpe brukerne med å forstå bruken av dem bedre.'
              },
              "third-party": {
                description: 'Dette er falske tredjepartsapplikasjoner.'
              }
            },
          accept: "godta",
          acceptAll: "godta alle",
          declineAll: "avslå alle",
          enabled: "Aktivert",
          disabled: "ufør",
          },
         nl:{
           "analytics": {
              description: "Voorbeeld van een inline-trackingscript dat een dummy-cookie plaatst",
            },
            "external-tracker": {
              description: "Voorbeeld van een extern tracking-script dat een dummy-cookie plaatst",
            },
            "always-on": {
              description: "Deze voorbeeld app zal geen cookie plaatsen",
            },
            "disabled-by-default": {
              description: "Deze voorbeeld app zal geen cookie plaatsen",
            },
            purposes: {
              analytics: "analyse",
              security: "beveiliging",
              ads: "advertenties"
            },
            categories: {
              example: {
                description: 'Toepassingen kunnen worden gegroepeerd in categorieën om gebruikers een beter inzicht te geven in hun gebruik.'
              },
              "third-party": {
                description: 'Dit zijn valse toepassingen van derden.'
              }
            }
         },
        ro:{
          "analytics": {
              description: "Exemplu de script de urmărire în linie care setează un cookie fictiv",
            },
            "external-tracker": {
              description: "Exemplu de script de urmărire externă care setează un cookie fictiv",
            },
            "always-on": {
              description: "Această aplicație de exemplu nu va seta niciun cookie",
            },
            "disabled-by-default": {
              description: "Această aplicație de exemplu nu va seta niciun cookie",
            },
            purposes: {
              analytics: "analiză",
              security: "securitate",
              ads: "anunțuri"
            },
            categories: {
              example: {
                description: 'Aplicațiile pot fi grupate în categorii pentru a-i ajuta pe utilizatori să înțeleagă mai bine utilizarea lor.'
              },
              "third-party": {
                description: 'Acestea sunt aplicații terțe false.'
              }
            },
          accept: "acceptă",
          acceptAll: "accepta toate",
          declineAll: "declina toate",
          enabled: "activat",
          disabled: "dezactivat",
        },  
    }, 
    <?php echo $codeeditor; ?> 
}
</script>
<script  type="opt-in" data-type="application/javascript" data-name="inline-tracker">          
           function setCookie(name, value, days) {
            console.log("This is an example of an inline tracking script.")
                var expires = "";
                if (days) {
                    var date = new Date();
                    date.setTime(date.getTime() + (days*24*60*60*1000));
                    expires = "; expires=" + date.toUTCString();
                }
                document.cookie = name + "=" + (value || "")  + expires + "; path=/";
            }

            //we set a tracking cookie as an example
            setCookie("inline-tracker", "foo", 120);
</script>
<?php }
function footerscript(){
$gtm_tag = get_option('gtm_tag');
if($gtm_tag != '') {
?>
<!-- Google Tag Manager (noscript) by gdpr plugin -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo $gtm_tag; ?>"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php 
 }
}
add_action('wp_footer','footerscript');

function headerstyle(){
$save_color = get_option('savebtn_color');
 if(isset($save_color) && !empty($save_color)){
   ?>
  <style type="text/css">
    .orejime-Button--save,.orejime-Button--accept{
       background-color: <?=$save_color?>;
    }
.orejime-AppItem-input:checked + .orejime-AppItem-label .orejime-AppItem-slider {
    background-color: <?=$save_color?>;
}
  </style>
<?php }else{?>
<style type="text/css">
  .orejime-Button--save,
 .orejime-Button--accept {
  background-color: #98012e;
  color: #fff; }
</style>
<?php }
}
add_action('wp_head','headerstyle');