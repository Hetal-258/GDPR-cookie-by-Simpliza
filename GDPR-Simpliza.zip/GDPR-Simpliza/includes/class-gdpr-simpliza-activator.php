<?php

/**
 * Fired during plugin activation
 *
 * @link       https://http://localhost/demo/
 * @since      1.0.0
 *
 * @package    Gdpr_Simpliza
 * @subpackage Gdpr_Simpliza/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Gdpr_Simpliza
 * @subpackage Gdpr_Simpliza/includes
 * @author     Simpliza <devtest7281@gmail.com>
 */
class Gdpr_Simpliza_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
