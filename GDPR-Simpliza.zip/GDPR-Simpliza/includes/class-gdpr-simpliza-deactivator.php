<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://http://localhost/demo/
 * @since      1.0.0
 *
 * @package    Gdpr_Simpliza
 * @subpackage Gdpr_Simpliza/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Gdpr_Simpliza
 * @subpackage Gdpr_Simpliza/includes
 * @author     Simpliza <devtest7281@gmail.com>
 */
class Gdpr_Simpliza_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
