<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://http://localhost/demo/
 * @since      1.0.0
 *
 * @package    Gdpr_Simpliza
 * @subpackage Gdpr_Simpliza/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Gdpr_Simpliza
 * @subpackage Gdpr_Simpliza/includes
 * @author     Simpliza <devtest7281@gmail.com>
 */
class Gdpr_Simpliza_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'gdpr-simpliza',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
